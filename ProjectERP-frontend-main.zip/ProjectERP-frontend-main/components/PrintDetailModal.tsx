"use client";

import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";

export interface PrintField {
  label: string;
  value: ReactNode;
}

interface PrintDetailModalProps {
  /** หัวเอกสาร เช่น "รายละเอียดสินค้า" */
  title: string;
  /** บรรทัดรองใต้หัวเอกสาร เช่น รหัส + ชื่อ */
  subtitle?: string;
  fields: PrintField[];
  onClose: () => void;
}

/** แปลงวันที่เป็นรูปแบบไทย (พ.ศ.) ถ้าไม่มีค่าให้แสดง "-" */
export function fmtDate(value?: string | null): string {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("th-TH", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/** แสดงค่าว่างเป็น "-" */
export function dash(value?: string | number | null): string {
  if (value === null || value === undefined || value === "") return "-";
  return String(value);
}

export default function PrintDetailModal({
  title,
  subtitle,
  fields,
  onClose,
}: PrintDetailModalProps) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  if (typeof document === "undefined") return null;

  const printedAt = new Date().toLocaleString("th-TH", {
    dateStyle: "long",
    timeStyle: "short",
  });

  return createPortal(
    <div
      id="print-root"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 print:static print:block print:bg-transparent print:p-0"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-lg bg-white shadow-xl print:max-h-none print:max-w-none print:overflow-visible print:rounded-none print:shadow-none">
        {/* แถบปุ่ม (ไม่ถูกพิมพ์) */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4 print:hidden">
          <h2 className="text-lg font-bold text-slate-800">{title}</h2>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              พิมพ์เอกสาร
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              ปิด
            </button>
          </div>
        </div>

        {/* ตัวเอกสาร (ส่วนนี้คือสิ่งที่ถูกพิมพ์) */}
        <div className="overflow-y-auto p-8 text-slate-900 print:overflow-visible print:p-0">
          <div className="border-b-2 border-slate-800 pb-4">
            <p className="text-xs text-slate-500">เอกสารข้อมูลหลัก</p>
            <h1 className="mt-1 text-2xl font-bold">{title}</h1>
            {subtitle && (
              <p className="mt-1 text-sm text-slate-700">{subtitle}</p>
            )}
          </div>

          <table className="mt-6 w-full border-collapse text-sm">
            <tbody>
              {fields.map((f) => (
                <tr key={f.label} className="break-inside-avoid">
                  <th
                    scope="row"
                    className="w-1/3 border border-slate-300 bg-slate-50 px-4 py-2.5 text-left font-medium text-slate-700 [-webkit-print-color-adjust:exact] [print-color-adjust:exact]"
                  >
                    {f.label}
                  </th>
                  <td className="border border-slate-300 px-4 py-2.5 whitespace-pre-line">
                    {f.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <p className="mt-6 text-right text-xs text-slate-500">
            พิมพ์เมื่อ {printedAt}
          </p>
        </div>
      </div>
    </div>,
    document.body,
  );
}
