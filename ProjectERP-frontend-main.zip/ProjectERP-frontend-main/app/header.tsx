"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { authApi } from "@/lib/api";
import { useSearch } from "@/components/SearchContext";

export default function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const { query, setQuery } = useSearch();
  const inputRef = useRef<HTMLInputElement>(null);

  // กด "/" ที่ไหนก็ได้ในหน้า เพื่อกระโดดไปที่ช่องค้นหา
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "/" || e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === "INPUT" ||
          t.tagName === "TEXTAREA" ||
          t.tagName === "SELECT" ||
          t.isContentEditable)
      )
        return;
      e.preventDefault();
      inputRef.current?.focus();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    import("@/lib/api/client").then(({ getStoredToken }) => {
      setIsLoggedIn(!!getStoredToken());
    });
  }, [pathname]);

  const handleLogout = async () => {
    try {
      authApi.logout();
      setIsLoggedIn(false);
      router.push("/auth/login");
      router.refresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white px-4 sm:px-6 lg:px-8">
      {/* Search */}
      <div className="flex flex-1 items-center pr-4">
        <form
          role="search"
          className="w-full max-w-xl"
          onSubmit={(e) => e.preventDefault()}
        >
          <label htmlFor="search-field" className="sr-only">
            ค้นหาเอกสาร หรือชื่อลูกค้า/ผู้ขาย
          </label>
          <div className="group relative">
            <svg
              className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-blue-600"
              viewBox="0 0 20 20"
              fill="currentColor"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z"
                clipRule="evenodd"
              />
            </svg>
            <input
              ref={inputRef}
              id="search-field"
              type="text"
              inputMode="search"
              autoComplete="off"
              name="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  setQuery("");
                  e.currentTarget.blur();
                }
              }}
              placeholder="ค้นหาเอกสาร ชื่อ หรือรหัส..."
              className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50 pl-11 pr-14 text-sm text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
            <div className="absolute inset-y-0 right-2.5 flex items-center">
              {query ? (
                <button
                  type="button"
                  onClick={() => {
                    setQuery("");
                    inputRef.current?.focus();
                  }}
                  aria-label="ล้างคำค้นหา"
                  className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-200 text-slate-500 transition hover:bg-slate-300 hover:text-slate-700"
                >
                  <svg
                    className="h-3.5 w-3.5"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                  </svg>
                </button>
              ) : (
                <kbd className="hidden rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[11px] font-medium text-slate-400 sm:block">
                  /
                </kbd>
              )}
            </div>
          </div>
        </form>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-x-4 lg:gap-x-6">
        {isLoggedIn ? (
          <>
            <Link
              href="/auth/profile"
              className="flex items-center gap-x-2 text-sm font-semibold leading-6 text-slate-900 hover:text-slate-700"
            >
              <span className="flex flex-col text-right">
                <span>ผู้ดูแลระบบ</span>
                <span className="text-xs font-normal text-slate-500">
                  ผู้ดูแลระบบ
                </span>
              </span>
            </Link>
            <div className="h-6 w-px bg-slate-200" aria-hidden="true"></div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-x-2 text-sm font-medium leading-6 text-slate-600 hover:text-slate-900"
            >
              <svg
                className="h-5 w-5 text-slate-400"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth="1.5"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"
                />
              </svg>
              ออกจากระบบ
            </button>
          </>
        ) : (
          <Link
            href="/auth/login"
            className="text-sm font-semibold leading-6 text-slate-900"
          >
            เข้าสู่ระบบ <span aria-hidden="true">&rarr;</span>
          </Link>
        )}
      </div>
    </header>
  );
}
